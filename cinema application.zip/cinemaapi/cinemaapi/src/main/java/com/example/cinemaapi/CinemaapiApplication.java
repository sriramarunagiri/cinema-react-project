package com.example.cinemaapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CinemaapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(CinemaapiApplication.class, args);
	}

}
