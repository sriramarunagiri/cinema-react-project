package com.example.cinemaapi;

public interface ReviewService {

	Reviews addReview(String string, String string2);

	String delete(Long id);

}
