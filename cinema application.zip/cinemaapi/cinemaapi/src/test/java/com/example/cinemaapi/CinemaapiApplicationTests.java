package com.example.cinemaapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CinemaapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
